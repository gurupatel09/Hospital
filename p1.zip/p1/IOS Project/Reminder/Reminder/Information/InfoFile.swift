//
//  InfoFile.swift
//  Reminder
//
//  Created by guru patel on 2017-11-14.
//  Copyright © 2017 guru patel. All rights reserved.
//

import Foundation

class InfoFile
{
    static var docName : [String] = ["Keon", "Simon"]
    static var docDept : [String] = ["Optometrics", "Neurologist"]
    
    static var patName : [String] = ["Dhruv", "Guru"]
    static var patAge : [String] = ["21", "23"]
    static var patSex : [String] = ["M", "M"]
    static var patAddress : [String] = ["Eto 22", "Eto 23"]
    static var patArrivalDate : [String] = ["2017-02-05", "2017-03-15"]
    
    static var empName : [String] = ["William", "Melissa"]
    static var empGender : [String] = ["M", "F"]
    static var empAge : [String] = ["28", "25"]
    static var empAddress : [String] = ["Scarborough", "Finch"]
    static var empShift : [String] = ["Day", "Night"]
    static var empDesignation : [String] = ["Ward Boy", "Assistant"]
    
    static var billDate : [String] = ["2017-02-15", "2017-03-20"]
    static var billAmount : [String] = ["500", "350"]
    static var billPatName : [String] = ["Dhruv", "Guru"]
    static var billPatRoom : [String] = ["3", "2"]
    static var billPatAssignDoc : [String] = ["Keon", "Simon"]
    
    static var medName : [String] = ["Aspirine", "Revital", "Paracetamol"]
    static var medQuantity : [String] = ["35", "43", "34"]
    static var medPrice : [String] = ["$40", "$45", "$50"]
    
    static var roomNo : [String] = ["101", "102"]
    static var roomAmount : [String] = ["$75", "$125"]
    static var roomAssignedToPat : [String] = ["Dhruv", "Guru"]
}
