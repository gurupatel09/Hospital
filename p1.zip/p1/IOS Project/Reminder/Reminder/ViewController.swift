//
//  ViewController.swift
//  Reminder
//
//  Created by guru patel on 2017-11-12.
//  Copyright © 2017 guru patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var menuButton: UIBarButtonItem!
    
    @IBAction func docButton(_ sender: UIButton) {
    }
    
    @IBAction func empButton(_ sender: UIButton) {
    }
    
    @IBAction func patButton(_ sender: UIButton) {
    }
    
    @IBAction func medButton(_ sender: UIButton) {
    }
    
    @IBAction func billButton(_ sender: UIButton) {
    }
    
    @IBAction func roomButton(_ sender: UIButton) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Hospital Management"
     /*   sideMenus()  */
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
 /*   func sideMenus()
    {
    if revealViewController() != nil
    {
        menuButton.target = revealViewController()
        menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
        revealViewController().rearViewRevealWidth = 275
        view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
        
    }*/

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
